import React, { Component } from 'react';

class DashboardFooter extends Component {
    state = {  }
    render() { 
        return (  
            <footer className="Dashboard_footer">
                  THE LAW CHALLENGE GHANA &copy; 2019
            </footer>
        );
    }
}
 
export default DashboardFooter;