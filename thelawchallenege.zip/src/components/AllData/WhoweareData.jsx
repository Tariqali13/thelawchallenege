export let data=[
    {
        span:'Generating competitive spirit among the law faculties.',
        
    },
    {
        span:'Shaping the destiny of the students of law towards the making of good lawyers who are alive to the role that law plays in the social, political, and economic advancement.',
    },
    {
        span:'Bringing the study of law to the door step of ordinary Ghanaians.',
    },
    {
        span:'Creating public awareness on the importance of law in a developing nation',
    },
    {
        span:'Serving as a resource tool avenue for law students.',
    },
    {
        span:'spreading the awareness of various laws and landmark verdicts, rulings and judgments of the Judiciary',
    },
]