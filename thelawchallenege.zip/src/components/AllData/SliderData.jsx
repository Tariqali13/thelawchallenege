export let data=[
    {
        images:"slider1",
    },
    {
        images:"slider2",
    },
    {
        images:"slider3",
    },
    {
        images:"slider4",
    },
    {
        images:"slider5",
    },
    {
        images:"slider6",
    },
    {
        images:"slider7",
    },
 
]