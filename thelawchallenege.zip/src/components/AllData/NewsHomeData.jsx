
export let carouselitem=[
    {
        CardDeck:[
            {
                cardimage:"slider1",
                cardtitle:"card1",
                cardtext:"here is the text",
                cardDate:"Last updated 3 mins ago",
            },
            {
                cardimage:"slider1",
                cardtitle:"card2",
                cardtext:"here is the text",
                cardDate:"Last updated 3 mins ago",
            }
        ]
    },
    {
        CardDeck:[
            {
                cardimage:"slider1",
                cardtitle:"card1",
                cardtext:"here is the text",
                cardDate:"Last updated 3 mins ago",
            },
            {
                cardimage:"slider1",
                cardtitle:"card2",
                cardtext:"here is the text",
                cardDate:"Last updated 3 mins ago",
            }
        ]
    }
]