export let data = [
   
    {
        heading: 'Rewards and Prizes',
        detail: 'The organizers will award the following prizes:',
        para: [
            {
                p1: "Winners- A winner trophy; Cash Prize; Laptop (3); Assorted Educational materials",
            },
            {
                p1: "1st Runner up- A 1st runner-up Trophy/ Plaque; Cash Prize; Assorted Educational materials ",
            },
            {
                p1: "2nd Runner up-  A 2nd runner-up Trophy/Plaque; Cash Prize; Assorted Educational materials",
            },
            {
                p1: "Certificate/engraved Plaque of participation shall be provided to every participant.",
            },
      
        ]
    },
    

]

export let data2 = [
  
    {
        h1: "Sponsorship Opportunities",
        p: "Promoter, sponsors and supporters will benefit from immense publicity and Investment Consult and Investment Consult",
        images: "sponsorship",
        btnvalue: 'Read More',
        color: 'red',
        to: "/Sponsorship",
        para: []
    },
   
    {
        h1:"Contact Us",
        p:"Get in touch with all your inquiries and your sponsorship too. We gladly await your call",
        images:"contact",
        btnvalue:'Contact us',
        to:"/ContactUs",
        para: []
    },
  

]