module.exports={
    DB:"mongodb+srv://TheLawChalleneg:Thelawchallenge123@thelawchallenge-pria4.mongodb.net/test?retryWrites=true&w=majority",
    
}